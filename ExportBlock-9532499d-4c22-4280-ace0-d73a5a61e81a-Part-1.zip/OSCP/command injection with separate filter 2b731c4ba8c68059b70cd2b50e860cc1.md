# command injection with separate filter

![image.png](command%20injection%20with%20separate%20filter/image.png)