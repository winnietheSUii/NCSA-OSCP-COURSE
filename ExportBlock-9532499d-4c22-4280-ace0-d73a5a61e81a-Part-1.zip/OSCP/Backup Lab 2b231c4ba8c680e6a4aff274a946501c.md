# Backup Lab

[https://github.com/tismayil/ohmybackup](https://github.com/tismayil/ohmybackup)

[http://34.142.247.64/index.php.backup](http://34.142.247.64/index.php.backup)

2

┌──(winniethesuii㉿winniethesuii)-[~/Downloads]
└─$ strings index.php.swp
b0VIM 8.0
root
vpn-techsuii
/opt/git/secplayground_labdocker/web/backup-lab2/src/index.php
3210
#"!
</html>
//The flag is web{sHKg3AsNFL}
<?php
</body>
<script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="../../dist/js/bootstrap.min.js"></script>
<script src="[https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js](https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js)" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="[https://code.jquery.com/jquery-3.1.1.slim.min.js](https://code.jquery.com/jquery-3.1.1.slim.min.js)" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<!-- Placed at the end of the document so the pages load faster -->
================================================== -->
<!-- Bootstrap core JavaScript
</div> <!-- /container -->
</footer>
<p>© SEC Playground Company 2017</p>
<footer>
<hr>
</div>
<div class="row">
<div class="container">
</div>
</div>
<p class="lead">Please find the flag in backup file of index file (such as index.php.bak, etc.)</p>
<h2 class="display-3">Welcome to a dump website</h1>
<div class="container">
<div class="jumbotron">
<!-- Main jumbotron for a primary marketing message or call to action -->
</nav>
</div>
<div class="collapse navbar-collapse" id="navbarsExampleDefault">
<a class="navbar-brand" href="#">SEC Playground# Backup file</a>
</button>
<span class="navbar-toggler-icon"></span>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
<nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse">
<body>
</head>
<!-- <link href="jumbotron.css" rel="stylesheet"> -->
<!-- Custom styles for this template -->
<link href="dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap core CSS -->
<title>SEC Playground# Backup file</title>
<link rel="icon" href="../../favicon.ico">
<meta name="author" content="">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta charset="utf-8">
<head>
<html lang="en">