# Robots.txt คืออะไร

[http://34.87.111.36/robots.txt](http://34.87.111.36/robots.txt)

```
User-agent: *
Disallow: /secret_xclbmsldmfg.txt
```

[http://34.87.111.36/secret_xclbmsldmfg.txt](http://34.87.111.36/secret_xclbmsldmfg.txt)

`web{dhP7zDjjGK}`