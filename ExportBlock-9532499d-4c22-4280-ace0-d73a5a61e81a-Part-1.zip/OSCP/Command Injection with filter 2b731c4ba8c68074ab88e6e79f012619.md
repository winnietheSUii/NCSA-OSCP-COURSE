# Command Injection with filter

![image.png](Command%20Injection%20with%20filter/image.png)